require(["game"], function(Game) {
});