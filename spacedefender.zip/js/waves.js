define(function() {
	return function() {
		return [
			{
				type: "zipper",
				delay: 500,
				X: 100
			},
			{
				type: "zipper",
				delay: 500,
				X: 100
			},
			{
				type: "zipper",
				delay: 500,
				X: 100
			},								
			{
				type: "hauler",
				delay: 5000,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},										
			{
				type: "hauler",
				delay: 1000,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},

			{
				type: "pirate",
				delay: 1000,
				X: 100
			},
			{
				type: "pirate",
				delay: 200,
				X: 200
			},	
			{
				type: "pirate",
				delay: 200,
				X: 300
			},
			{
				type: "pirate",
				delay: 200,
				X: 400
			},
			{
				type: "pirate",
				delay: 200,
				X: 500
			},
			{
				type: "pirate",
				delay: 200,
				X: 600
			},
			{
				type: "pirate",
				delay: 200,
				X: 700
			},
			{
				type: "zipper",
				delay: 500,
				X: 100
			},
			{
				type: "zipper",
				delay: 500,
				X: 100
			},
			{
				type: "zipper",
				delay: 500,
				X: 100
			},								
			{
				type: "hauler",
				delay: 5000,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},
			{
				type: "hauler",
				delay: 500,
				X: 200
			},										
			{
				type: "hauler",
				delay: 1000,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},
			{
				type: "hauler",
				delay: 500,
				X: 600
			},

			{
				type: "schooner",
				delay: 1000,
				X: 100
			},
			{
				type: "schooner",
				delay: 700,
				X: 200
			},	
			{
				type: "schooner",
				delay: 700,
				X: 300
			},
			{
				type: "schooner",
				delay: 700,
				X: 400
			},
			{
				type: "schooner",
				delay: 700,
				X: 500
			},
			{
				type: "schooner",
				delay: 700,
				X: 600
			},
			{
				type: "schooner",
				delay: 700,
				X: 700
			},
			{
				type: "schooner",
				delay: 1000,
				X: 100
			},
			{
				type: "schooner",
				delay: 700,
				X: 200
			},	
			{
				type: "schooner",
				delay: 700,
				X: 300
			},
			{
				type: "schooner",
				delay: 700,
				X: 400
			},
			{
				type: "schooner",
				delay: 700,
				X: 500
			},
			{
				type: "schooner",
				delay: 700,
				X: 600
			},
			{
				type: "schooner",
				delay: 700,
				X: 700
			},





			{
				type: "tube",
				delay: 700,
				X: 100
			},
			{
				type: "tube",
				delay: 700,
				X: 100
			},
			{
				type: "tube",
				delay: 700,
				X: 100
			},								
			{
				type: "zipper",
				delay: 5000,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},										
			{
				type: "zipper",
				delay: 1000,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},

			{
				type: "shuttle",
				delay: 1000,
				X: 100
			},
			{
				type: "shuttle",
				delay: 700,
				X: 200
			},	
			{
				type: "shuttle",
				delay: 700,
				X: 300
			},
			{
				type: "shuttle",
				delay: 700,
				X: 400
			},
			{
				type: "shuttle",
				delay: 700,
				X: 500
			},
			{
				type: "shuttle",
				delay: 700,
				X: 600
			},
			{
				type: "shuttle",
				delay: 700,
				X: 700
			},
			{
				type: "tube",
				delay: 500,
				X: 100
			},
			{
				type: "tube",
				delay: 500,
				X: 100
			},
			{
				type: "tube",
				delay: 500,
				X: 100
			},								
			{
				type: "zipper",
				delay: 5000,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},										
			{
				type: "zipper",
				delay: 1000,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},

			{
				type: "waterhauler",
				delay: 1000,
				X: 100
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 200
			},	
			{
				type: "waterhauler",
				delay: 700,
				X: 300
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 400
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 500
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 600
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 700
			},
			{
				type: "waterhauler",
				delay: 1000,
				X: 100
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 200
			},	
			{
				type: "waterhauler",
				delay: 700,
				X: 300
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 400
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 500
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 600
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 700
			},
			{
				type: "elder",
				delay: 2000,
				X: 400
			},


			{
				type: "tube",
				delay: 700,
				X: 100
			},
			{
				type: "tube",
				delay: 700,
				X: 100
			},
			{
				type: "tube",
				delay: 700,
				X: 100
			},								
			{
				type: "zipper",
				delay: 5000,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},										
			{
				type: "zipper",
				delay: 1000,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},

			{
				type: "shuttle",
				delay: 1000,
				X: 100
			},
			{
				type: "shuttle",
				delay: 700,
				X: 200
			},	
			{
				type: "shuttle",
				delay: 700,
				X: 300
			},
			{
				type: "shuttle",
				delay: 700,
				X: 400
			},
			{
				type: "shuttle",
				delay: 700,
				X: 500
			},
			{
				type: "shuttle",
				delay: 700,
				X: 600
			},
			{
				type: "shuttle",
				delay: 700,
				X: 700
			},
			{
				type: "tube",
				delay: 500,
				X: 100
			},
			{
				type: "tube",
				delay: 500,
				X: 100
			},
			{
				type: "tube",
				delay: 500,
				X: 100
			},								
			{
				type: "zipper",
				delay: 5000,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},
			{
				type: "zipper",
				delay: 500,
				X: 200
			},										
			{
				type: "zipper",
				delay: 1000,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},
			{
				type: "zipper",
				delay: 500,
				X: 600
			},

			{
				type: "waterhauler",
				delay: 1000,
				X: 100
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 200
			},	
			{
				type: "waterhauler",
				delay: 700,
				X: 300
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 400
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 500
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 600
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 700
			},
			{
				type: "waterhauler",
				delay: 1000,
				X: 100
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 200
			},	
			{
				type: "waterhauler",
				delay: 700,
				X: 300
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 400
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 500
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 600
			},
			{
				type: "waterhauler",
				delay: 700,
				X: 700
			},
			{
				type: "elder",
				delay: 2000,
				X: 400
			},
			{
				type: "elder",
				delay: 1000,
				X: 400
			},
			{
				type: "elder",
				delay: 1000,
				X: 400
			}
		];
	};
});